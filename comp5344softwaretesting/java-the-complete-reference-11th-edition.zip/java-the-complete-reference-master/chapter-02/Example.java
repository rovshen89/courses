/**
 * C02 L01
 * 
 * This is a simple Java program. Call this file "Example.java"
 */
public class Example {

    public static void main(String[] args) {
        System.out.println("This is a simple Java program.");
    }
}