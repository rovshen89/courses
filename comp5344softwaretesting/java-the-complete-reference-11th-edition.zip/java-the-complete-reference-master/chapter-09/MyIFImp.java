/**
 * C09 L12
 * 
 * Implement MyIF.
 */
class MyIFImp implements MyIF {
    public int getNumber() {
        return 100;
    }
}