import mypack.*;

/**
 * C09 L03
 */

public class TestBalance {

    public static void main(String[] args) {
        Balance test = new Balance("J. J. Jaspers", 99.88);

        test.show();
    }
}