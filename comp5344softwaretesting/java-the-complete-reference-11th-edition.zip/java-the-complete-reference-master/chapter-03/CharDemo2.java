/**
 * C03 L04
 * 
 * char variables behave like integers.
 */
public class CharDemo2 {

    public static void main(String[] args) {
        char ch1;

        ch1 = 'X';
        System.out.println("ch1 contains " + ch1);

        ch1++;
        System.out.println("ch1 is now " + ch1);
    }
}