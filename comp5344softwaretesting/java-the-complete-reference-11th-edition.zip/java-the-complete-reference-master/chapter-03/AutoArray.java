/**
 * C03 L12
 * 
 * An improved version of the previous program.
 */
public class AutoArray {

    public static void main(String[] args) {
        int month_days[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        System.out.println("April has " + month_days[12] + " days.");
    }
}