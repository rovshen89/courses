package demo.pkg;

public class Calculator
{
    //member variables
    private int c_x;
    private int c_y;

    public int v;

    public Calculator()
    {

    }

    public Calculator(Calculator c)
    {

    }

    public Calculator(int x, int y)
    {
        this.c_x = x;
        this.c_y = y;
    }

    public int get_cx()
    {
        return this.c_x;
    }
    public int get_cy()
    {
        return this.c_y;
    }

    /*
    * It accepts two integer type, adds and then returns int type
    * x = 1,.....,65,535
    * y = 1,.......,65,535*/
    //member functions
    public int add(int x, int y)
    {
        return x+y;
    }

    public double add_double(double x, double y)
    {
        return x+y;
    }

    public int count_one(String s)
    {
        int count = 0;
        for(int i = 0; i < s.length(); i++)
        {
            if(s.charAt(i)=='1')    //s[i]
            {
                count++;
            }

        }
        return count;
    }

    public static void main(String[] args)
    {
        Calculator c = new Calculator(10,20);
        System.out.println(c.get_cx());
        System.out.println(c.get_cy());
        c.v = 1000;

    }

}
