package demo.pkg.test;

import demo.pkg.Calculator;
import org.junit.Test;
import org.mockito.Mock;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class CalculatorTest {

    @Mock
    Calculator cMock;

    @Test
    //p(d)
    public void test_add()
    {
        Calculator c = new Calculator(); //Calculator class object initialization
        assertEquals(c.add(2,1),3); //T0
        assertEquals(c.add(2,2),4);  //T1   // T1 subset T0 since T1(x) = T0(x)
        assertEquals(c.add(4,5),9); //T ={{2,1},{2,2},{4,5}}
        //assertEquals(c.add(3.50,2.00),5.50);
    }

    @Test
    public void test_add_double()
    {
        Calculator c = new Calculator();
        assertEquals(c.add_double(2.5,3.5),6,0.0);
    }

    public void test_count_one()
    {
        Calculator c = new Calculator(); //Calculator class object initialization
        int v = c.count_one("11100001111");
        assertEquals(v,7);

    }

    @Test
    public void test_add_mock()
    {
        Calculator c = new Calculator(cMock);
        assertEquals(c.add(2,1),3);
    }

}